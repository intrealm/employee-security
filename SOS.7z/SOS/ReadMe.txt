In this, we have:
1. Entity
2. Repo
3. Controller class to test entry creation in database for SOS
4. Service to call dao to create SOS entry
5. Dao to create entry in table.