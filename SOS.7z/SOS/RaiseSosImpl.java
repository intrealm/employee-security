package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.dao.RaiseSosDaoImpl;

@Component
public class RaiseSosImpl {
	
	@Autowired
	private RaiseSosDaoImpl raiseSosDaoImpl;

	
	public String raiseSosService(String username, int routeNumber) {

		boolean output = raiseSosDaoImpl.createSos(username, routeNumber);
		if(output) {
			// send SMS
			return "SOS Raised";
		} else {
			return "SOS Not Raised";
		}
		
	}
}
